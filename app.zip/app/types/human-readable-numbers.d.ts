declare module "human-readable-numbers" {
  export function toHumanString(n: number): string;
}
